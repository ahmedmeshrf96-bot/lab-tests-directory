@echo off
setlocal
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
pyinstaller --noconfirm --clean --onefile --windowed --name "Tahalil-Alakkad" --icon "assets\app.ico" --add-data "config.json;." --add-data "assets;assets" app.py
if errorlevel 1 exit /b 1
echo.
echo BUILD SUCCESSFUL
echo EXE: dist\Tahalil-Alakkad.exe
pause
