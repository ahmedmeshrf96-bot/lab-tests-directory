from __future__ import annotations

import json
import math
import os
import sys
import time
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from PySide6.QtCore import Qt, QObject, QRunnable, QThreadPool, Signal
from PySide6.QtGui import QIcon, QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QDialog, QLabel, QPushButton, QLineEdit,
    QVBoxLayout, QHBoxLayout, QGridLayout, QFormLayout, QTableWidget,
    QTableWidgetItem, QMessageBox, QStackedWidget, QFrame, QTextEdit, QComboBox,
    QSpinBox, QDoubleSpinBox, QHeaderView, QAbstractItemView, QGroupBox, QSplitter,
    QDateEdit, QInputDialog
)

from firebase_client import FirebaseClient, FirebaseError


APP_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
CONFIG_PATH = APP_DIR / "config.json"
ASSETS = APP_DIR / "assets"
MANAGER_UID = "Wps5Y19pZSbeGooEzFfW5UFsshq2"


def now_ms() -> int:
    return int(time.time() * 1000)


def normalize_phone(value: str) -> str:
    return "".join(ch for ch in value if ch.isdigit())


def normalize_text(value: str) -> str:
    text = (value or "").strip().lower()
    swaps = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ى": "ي", "ة": "ه", "ؤ": "و", "ئ": "ي"})
    return " ".join(text.translate(swaps).split())


def money(value: float) -> str:
    if abs(value - round(value)) < 0.0001:
        return f"{int(round(value)):,}"
    return f"{value:,.2f}".rstrip("0").rstrip(".")


def generate_file_number(ts: int) -> str:
    d = datetime.fromtimestamp(ts / 1000)
    return f"AK-{d:%y%m%d-%H%M%S}-{ts % 1000:03d}"


def generate_order_number(ts: int, doc_id: str) -> str:
    d = datetime.fromtimestamp(ts / 1000)
    return f"ORD-{d:%y%m%d-%H%M%S}-{doc_id[-4:].upper()}"


def friendly_time(ts: int) -> str:
    if not ts:
        return "—"
    return datetime.fromtimestamp(ts / 1000).strftime("%d/%m/%Y %I:%M %p")


class WorkerSignals(QObject):
    result = Signal(object)
    error = Signal(str)
    finished = Signal()


class Worker(QRunnable):
    def __init__(self, fn: Callable[[], Any]):
        super().__init__()
        self.fn = fn
        self.signals = WorkerSignals()

    def run(self):
        try:
            result = self.fn()
            self.signals.result.emit(result)
        except Exception as exc:
            self.signals.error.emit(str(exc))
        finally:
            self.signals.finished.emit()


class Card(QFrame):
    def __init__(self, title: str, value: str = "", subtitle: str = ""):
        super().__init__()
        self.setObjectName("card")
        layout = QVBoxLayout(self)
        title_label = QLabel(title)
        title_label.setObjectName("cardTitle")
        self.value_label = QLabel(value)
        self.value_label.setObjectName("cardValue")
        subtitle_label = QLabel(subtitle)
        subtitle_label.setObjectName("muted")
        subtitle_label.setWordWrap(True)
        layout.addWidget(title_label)
        layout.addWidget(self.value_label)
        if subtitle:
            layout.addWidget(subtitle_label)

    def set_value(self, value: str):
        self.value_label.setText(value)


class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.client = FirebaseClient(CONFIG_PATH)
        self.pool = QThreadPool.globalInstance()
        self.setWindowTitle("تحاليل العقاد")
        self.setMinimumSize(460, 560)
        self.setWindowIcon(QIcon(str(ASSETS / "app.ico")))
        self._build()

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(60, 55, 60, 55)
        outer.setSpacing(18)

        logo = QLabel()
        logo.setPixmap(QIcon(str(ASSETS / "logo.png")).pixmap(130, 130))
        logo.setAlignment(Qt.AlignCenter)
        title = QLabel("تحاليل العقاد")
        title.setObjectName("loginTitle")
        title.setAlignment(Qt.AlignCenter)
        sub = QLabel("نظام إدارة العملاء والطلبات")
        sub.setObjectName("muted")
        sub.setAlignment(Qt.AlignCenter)

        self.email = QLineEdit()
        self.email.setPlaceholderText("البريد الإلكتروني")
        self.email.setLayoutDirection(Qt.LeftToRight)
        self.password = QLineEdit()
        self.password.setPlaceholderText("كلمة المرور")
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setLayoutDirection(Qt.LeftToRight)
        self.password.returnPressed.connect(self.login)
        self.btn = QPushButton("تسجيل الدخول")
        self.btn.setObjectName("primaryButton")
        self.btn.clicked.connect(self.login)
        self.status = QLabel("")
        self.status.setObjectName("error")
        self.status.setAlignment(Qt.AlignCenter)
        self.status.setWordWrap(True)

        outer.addStretch()
        outer.addWidget(logo)
        outer.addWidget(title)
        outer.addWidget(sub)
        outer.addSpacing(15)
        outer.addWidget(self.email)
        outer.addWidget(self.password)
        outer.addWidget(self.btn)
        outer.addWidget(self.status)
        outer.addStretch()

    def login(self):
        email = self.email.text().strip()
        password = self.password.text()
        if not email or not password:
            self.status.setText("اكتب البريد الإلكتروني وكلمة المرور")
            return
        self.btn.setEnabled(False)
        self.btn.setText("جاري تسجيل الدخول...")
        self.status.setText("")

        def task():
            self.client.sign_in(email, password)
            profile = self.client.get_or_create_profile()
            if profile.get("enabled", True) is False:
                raise FirebaseError("هذا الحساب موقوف من الإدارة")
            return profile

        worker = Worker(task)
        worker.signals.result.connect(self._login_ok)
        worker.signals.error.connect(self._login_error)
        worker.signals.finished.connect(lambda: (self.btn.setEnabled(True), self.btn.setText("تسجيل الدخول")))
        self.pool.start(worker)

    def _login_ok(self, profile: Dict[str, Any]):
        self.main = MainWindow(self.client, profile)
        self.main.showMaximized()
        self.close()

    def _login_error(self, text: str):
        self.status.setText(text)


class MainWindow(QMainWindow):
    def __init__(self, client: FirebaseClient, profile: Dict[str, Any]):
        super().__init__()
        self.client = client
        self.profile = profile
        self.pool = QThreadPool.globalInstance()
        self.customers_cache: List[Dict[str, Any]] = []
        self.customer_overrides: Dict[int, float] = {}
        self.lab2lab: Dict[int, float] = {}
        self.tests = self._load_tests()
        self.test_by_id = {int(t["id"]): t for t in self.tests}
        self.setWindowTitle("تحاليل العقاد")
        self.setWindowIcon(QIcon(str(ASSETS / "app.ico")))
        self.setMinimumSize(1100, 700)
        self._build_ui()
        self.load_prices()
        self.customers_page.refresh()
        if self.client.is_manager:
            self.dashboard_page.refresh()

    def _load_tests(self) -> List[Dict[str, Any]]:
        return json.loads((ASSETS / "lab_tests_android.json").read_text(encoding="utf-8"))

    def run_async(self, fn, ok=None, err=None, done=None):
        worker = Worker(fn)
        if ok:
            worker.signals.result.connect(ok)
        if err:
            worker.signals.error.connect(err)
        else:
            worker.signals.error.connect(lambda s: QMessageBox.critical(self, "خطأ", s))
        if done:
            worker.signals.finished.connect(done)
        self.pool.start(worker)
        return worker

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        layout = QHBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(230)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(18, 24, 18, 18)
        side.setSpacing(10)

        brand = QLabel("تحاليل العقاد")
        brand.setObjectName("brand")
        role = "Super Admin" if self.client.is_manager else (self.profile.get("display_name") or "مستخدم")
        user = QLabel(f"{self.profile.get('display_name') or self.client.email}\n{role}")
        user.setObjectName("sidebarUser")
        user.setWordWrap(True)
        side.addWidget(brand)
        side.addWidget(user)
        side.addSpacing(18)

        self.stack = QStackedWidget()
        self.dashboard_page = DashboardPage(self)
        self.customers_page = CustomersPage(self)
        self.orders_page = OrdersLookupPage(self)
        self.reports_page = ReportsPage(self)
        self.admin_page = AdminPage(self)

        self.pages = {
            "dashboard": self.dashboard_page,
            "customers": self.customers_page,
            "orders": self.orders_page,
            "reports": self.reports_page,
            "admin": self.admin_page,
        }
        for page in self.pages.values():
            self.stack.addWidget(page)

        def add_nav(text, key):
            b = QPushButton(text)
            b.setObjectName("navButton")
            b.clicked.connect(lambda: self.go(key))
            side.addWidget(b)
            return b

        add_nav("⌂  الرئيسية", "dashboard")
        add_nav("👥  العملاء", "customers")
        add_nav("🧾  طلبات العملاء", "orders")
        if self.client.is_manager:
            add_nav("📊  التقارير", "reports")
            add_nav("⚙  الإدارة", "admin")
        side.addStretch()
        refresh = QPushButton("↻  تحديث البيانات")
        refresh.setObjectName("navButton")
        refresh.clicked.connect(self.refresh_all)
        side.addWidget(refresh)
        logout = QPushButton("تسجيل الخروج")
        logout.setObjectName("dangerButton")
        logout.clicked.connect(self.close)
        side.addWidget(logout)

        layout.addWidget(sidebar)
        layout.addWidget(self.stack, 1)
        self.go("dashboard")

    def go(self, key: str):
        page = self.pages[key]
        self.stack.setCurrentWidget(page)
        if hasattr(page, "on_show"):
            page.on_show()

    def refresh_all(self):
        self.customers_page.refresh()
        self.load_prices()
        if self.client.is_manager:
            self.dashboard_page.refresh()

    def load_prices(self):
        def task():
            overrides = self.client.list_collection("customer_price_overrides")
            customer = {}
            for d in overrides:
                raw_id = str(d.get("_id", "")).replace("test_", "")
                try:
                    tid = int(raw_id if raw_id.isdigit() else d.get("id", 0))
                except Exception:
                    continue
                val = d.get("customer_price", d.get("price", 0))
                try:
                    customer[tid] = float(val)
                except Exception:
                    pass
            labs = {}
            if self.client.is_manager:
                for d in self.client.list_collection("lab2lab_prices"):
                    raw_id = str(d.get("_id", "")).replace("test_", "")
                    try:
                        tid = int(raw_id if raw_id.isdigit() else d.get("id", 0))
                    except Exception:
                        continue
                    val = d.get("lab_to_lab_price", d.get("lab2lab_price", d.get("price", 0)))
                    try:
                        labs[tid] = float(val)
                    except Exception:
                        pass
            return customer, labs
        def ok(result):
            self.customer_overrides, self.lab2lab = result
        self.run_async(task, ok=ok, err=lambda _: None)

    def effective_price(self, test: Dict[str, Any]) -> float:
        tid = int(test["id"])
        return float(self.customer_overrides.get(tid, test.get("customer_price", 0) or 0))

    def visible_customers(self) -> List[Dict[str, Any]]:
        if self.client.is_manager:
            return list(self.customers_cache)
        return [c for c in self.customers_cache if not c.get("is_archived", False)]

    def log_audit(self, action: str, entity_type: str, entity_id: str, title: str, details: str,
                  customer_id: str = "", order_id: str = ""):
        data = {
            "action": action, "entity_type": entity_type, "entity_id": entity_id,
            "customer_id": customer_id, "order_id": order_id,
            "title": title, "details": details,
            "actor_uid": self.client.uid, "actor_email": self.client.email,
            "created_at_ms": now_ms(),
        }
        try:
            self.client.set_document(f"audit_logs/{self.client.new_id()}", data, merge=False)
        except Exception:
            pass

    def add_activity(self, customer_id: str, typ: str, title: str, details: str):
        data = {
            "type": typ, "title": title, "details": details,
            "actor_uid": self.client.uid, "actor_email": self.client.email,
            "created_at_ms": now_ms(),
        }
        try:
            self.client.set_document(f"customers/{customer_id}/activity/{self.client.new_id()}", data, merge=False)
        except Exception:
            pass


class DashboardPage(QWidget):
    def __init__(self, main: MainWindow):
        super().__init__()
        self.main = main
        l = QVBoxLayout(self)
        l.setContentsMargins(34, 30, 34, 30)
        title = QLabel("لوحة التحكم")
        title.setObjectName("pageTitle")
        greeting = QLabel(f"مرحبًا، {main.profile.get('display_name') or main.client.email.split('@')[0]}")
        greeting.setObjectName("muted")
        l.addWidget(title)
        l.addWidget(greeting)

        cards = QGridLayout()
        self.c1 = Card("طلبات اليوم", "—")
        self.c2 = Card("تحصيل اليوم", "—")
        self.c3 = Card("إجمالي المديونيات", "—")
        cards.addWidget(self.c1, 0, 0)
        cards.addWidget(self.c2, 0, 1)
        cards.addWidget(self.c3, 0, 2)
        l.addLayout(cards)

        shortcuts = QGroupBox("اختصارات سريعة")
        g = QGridLayout(shortcuts)
        actions = [
            ("🧪\nطلب جديد", lambda: main.go("customers")),
            ("👥\nالعملاء", lambda: main.go("customers")),
            ("🧾\nالطلبات", lambda: main.go("orders")),
        ]
        if main.client.is_manager:
            actions += [
                ("📊\nالتقارير", lambda: main.go("reports")),
                ("⚙\nالإدارة", lambda: main.go("admin")),
            ]
        for i, (text, fn) in enumerate(actions):
            b = QPushButton(text)
            b.setObjectName("actionTile")
            b.setMinimumHeight(120)
            b.clicked.connect(fn)
            g.addWidget(b, i // 3, i % 3)
        l.addWidget(shortcuts)
        l.addStretch()

    def on_show(self):
        if self.main.client.is_manager:
            self.refresh()
        else:
            self.c1.set_value("—")
            self.c2.set_value("—")
            self.c3.set_value("—")

    def refresh(self):
        if not self.main.client.is_manager:
            return
        self.c1.set_value("...")
        self.c2.set_value("...")
        self.c3.set_value("...")

        def task():
            orders = self.main.client.run_collection_group("orders")
            start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp() * 1000
            valid = [o for o in orders if not o.get("is_voided", False)]
            today = [o for o in valid if int(o.get("created_at_ms", 0) or 0) >= start]
            return len(today), sum(float(o.get("paid_amount", 0) or 0) for o in today), sum(float(o.get("remaining_amount", 0) or 0) for o in valid)

        def ok(res):
            n, paid, remaining = res
            self.c1.set_value(str(n))
            self.c2.set_value(f"{money(paid)} ج")
            self.c3.set_value(f"{money(remaining)} ج")
        self.main.run_async(task, ok=ok, err=lambda _: None)


class CustomersPage(QWidget):
    def __init__(self, main: MainWindow):
        super().__init__()
        self.main = main
        l = QVBoxLayout(self)
        l.setContentsMargins(30, 24, 30, 24)
        head = QHBoxLayout()
        title = QLabel("العملاء")
        title.setObjectName("pageTitle")
        self.search = QLineEdit()
        self.search.setPlaceholderText("بحث بالاسم أو الموبايل أو رقم الملف أو العنوان أو Tag...")
        self.search.textChanged.connect(self.apply_filter)
        add = QPushButton("+ عميل جديد")
        add.setObjectName("primaryButton")
        add.clicked.connect(self.add_customer)
        ref = QPushButton("تحديث")
        ref.clicked.connect(self.refresh)
        head.addWidget(title)
        head.addStretch()
        head.addWidget(self.search, 2)
        head.addWidget(ref)
        head.addWidget(add)
        l.addLayout(head)

        self.status = QLabel("")
        self.status.setObjectName("muted")
        l.addWidget(self.status)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["رقم الملف", "الاسم", "الموبايل", "البديل", "الحالة", "آخر تحديث"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.doubleClicked.connect(self.open_selected)
        l.addWidget(self.table, 1)

        foot = QHBoxLayout()
        open_btn = QPushButton("فتح ملف العميل")
        open_btn.setObjectName("primaryButton")
        open_btn.clicked.connect(self.open_selected)
        edit_btn = QPushButton("تعديل البيانات")
        edit_btn.clicked.connect(self.edit_selected)
        order_btn = QPushButton("طلب جديد")
        order_btn.clicked.connect(self.new_order_selected)
        foot.addWidget(open_btn)
        foot.addWidget(edit_btn)
        foot.addWidget(order_btn)
        foot.addStretch()
        l.addLayout(foot)

    def on_show(self):
        self.apply_filter()

    def refresh(self):
        self.status.setText("جاري تحميل العملاء...")
        def task():
            return self.main.client.list_collection("customers")
        def ok(docs):
            docs.sort(key=lambda d: int(d.get("updated_at_ms", d.get("created_at_ms", 0)) or 0), reverse=True)
            self.main.customers_cache = docs
            self.status.setText(f"{len(self.main.visible_customers())} عميل")
            self.apply_filter()
        self.main.run_async(task, ok=ok, done=lambda: None)

    def apply_filter(self):
        q = normalize_text(self.search.text())
        rows = []
        for c in self.main.visible_customers():
            blob = normalize_text(" ".join([
                str(c.get("file_number", "")), str(c.get("name", "")), str(c.get("phone", "")),
                str(c.get("alternate_phone", "")), str(c.get("address", "")),
                " ".join(c.get("tags", []) if isinstance(c.get("tags"), list) else [])
            ]))
            if not q or q in blob:
                rows.append(c)
        self.table.setRowCount(len(rows))
        for r, c in enumerate(rows):
            status = "محذوف/مؤرشف" if c.get("is_archived") else ("بلاك ليست" if c.get("is_blacklisted") else "نشط")
            vals = [c.get("file_number", ""), c.get("name", ""), c.get("phone", ""), c.get("alternate_phone", ""), status, friendly_time(int(c.get("updated_at_ms", 0) or 0))]
            for col, val in enumerate(vals):
                item = QTableWidgetItem(str(val))
                item.setData(Qt.UserRole, c)
                self.table.setItem(r, col, item)

    def selected_customer(self) -> Optional[Dict[str, Any]]:
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.information(self, "العملاء", "اختر عميل أولًا")
            return None
        return self.table.item(row, 0).data(Qt.UserRole)

    def add_customer(self):
        dlg = CustomerEditDialog(self.main, None)
        if dlg.exec() == QDialog.Accepted:
            self.save_customer(dlg.data(), None)

    def edit_selected(self):
        c = self.selected_customer()
        if not c:
            return
        dlg = CustomerEditDialog(self.main, c)
        if dlg.exec() == QDialog.Accepted:
            self.save_customer(dlg.data(), c)

    def save_customer(self, data: Dict[str, Any], existing: Optional[Dict[str, Any]]):
        clean_phone = normalize_phone(data["phone"])
        clean_alt = normalize_phone(data.get("alternate_phone", ""))
        if len(clean_phone) < 8:
            QMessageBox.warning(self, "بيانات العميل", "اكتب رقم موبايل صحيح")
            return
        for c in self.main.customers_cache:
            if existing and c.get("_id") == existing.get("_id"):
                continue
            nums = {normalize_phone(str(c.get("phone", ""))), normalize_phone(str(c.get("alternate_phone", "")))}
            if clean_phone in nums or (clean_alt and clean_alt in nums):
                status = "محذوف/مؤرشف" if c.get("is_archived") else ("بلاك ليست" if c.get("is_blacklisted") else "نشط")
                QMessageBox.warning(self, "رقم مستخدم", f"الرقم مسجل للعميل {c.get('name')} • ملف {c.get('file_number')} • {status}")
                return

        def task():
            ts = now_ms()
            cid = existing.get("_id") if existing else self.main.client.new_id()
            file_no = existing.get("file_number") if existing else generate_file_number(ts)
            payload = {
                "file_number": file_no,
                "name": data["name"].strip(),
                "name_search": normalize_text(data["name"]),
                "phone": data["phone"].strip(),
                "phone_normalized": clean_phone,
                "alternate_phone": data.get("alternate_phone", "").strip(),
                "alternate_phone_normalized": clean_alt,
                "age": data.get("age", ""),
                "birth_date": data.get("birth_date", ""),
                "gender": data.get("gender", ""),
                "address": data.get("address", "").strip(),
                "address_search": normalize_text(data.get("address", "")),
                "notes": data.get("notes", "").strip(),
                "important_alert": data.get("important_alert", "").strip(),
                "tags": data.get("tags", []),
                "tags_search": normalize_text(" ".join(data.get("tags", []))),
                "default_discount_percent": float(data.get("default_discount_percent", 0)),
                "updated_at_ms": ts,
                "updated_by_uid": self.main.client.uid,
                "updated_by_email": self.main.client.email,
            }
            if not existing:
                payload.update({
                    "created_at_ms": ts,
                    "created_by_uid": self.main.client.uid,
                    "created_by_email": self.main.client.email,
                    "is_blacklisted": False, "blacklist_reason": "", "blacklisted_at_ms": 0,
                    "is_archived": False, "archived_at_ms": 0,
                })
            self.main.client.set_document(f"customers/{cid}", payload, merge=bool(existing))
            for phone in {clean_phone, clean_alt} - {""}:
                self.main.client.set_document(f"phone_registry/{phone}", {
                    "customer_id": cid, "phone": phone, "updated_at_ms": ts, "updated_by_uid": self.main.client.uid
                }, merge=True)
            if existing:
                old_nums = {normalize_phone(str(existing.get("phone", ""))), normalize_phone(str(existing.get("alternate_phone", "")))} - {""}
                for phone in old_nums - ({clean_phone, clean_alt} - {""}):
                    try:
                        self.main.client.delete_document(f"phone_registry/{phone}")
                    except Exception:
                        pass
            action = "customer_update" if existing else "customer_create"
            self.main.log_audit(action, "customer", cid, "تعديل بيانات العميل" if existing else "إنشاء عميل", f"{payload['name']} • {file_no}", customer_id=cid)
            self.main.add_activity(cid, action, "تعديل بيانات العميل" if existing else "إنشاء عميل", f"{payload['name']} • {file_no}")
            return cid
        def ok(_):
            QMessageBox.information(self, "تم", "تم حفظ بيانات العميل")
            self.refresh()
        self.main.run_async(task, ok=ok)

    def open_selected(self):
        c = self.selected_customer()
        if c:
            CustomerDetailDialog(self.main, c).exec()

    def new_order_selected(self):
        c = self.selected_customer()
        if not c:
            return
        if c.get("is_blacklisted"):
            QMessageBox.warning(self, "بلاك ليست", "العميل على البلاك ليست. لازم عبدالرحمن يفك الحظر قبل طلب جديد")
            return
        if c.get("is_archived"):
            QMessageBox.warning(self, "عميل مؤرشف", "لا يمكن إنشاء طلب لعميل مؤرشف")
            return
        dlg = NewOrderDialog(self.main, c)
        if dlg.exec() == QDialog.Accepted:
            self.refresh()


class CustomerEditDialog(QDialog):
    def __init__(self, main: MainWindow, customer: Optional[Dict[str, Any]]):
        super().__init__(main)
        self.main = main
        self.customer = customer or {}
        self.setWindowTitle("تعديل بيانات العميل" if customer else "عميل جديد")
        self.setMinimumWidth(620)
        form = QFormLayout(self)
        self.name = QLineEdit(str(self.customer.get("name", "")))
        self.phone = QLineEdit(str(self.customer.get("phone", "")))
        self.alt = QLineEdit(str(self.customer.get("alternate_phone", "")))
        self.age = QLineEdit(str(self.customer.get("age", "")))
        self.birth = QLineEdit(str(self.customer.get("birth_date", "")))
        self.gender = QComboBox(); self.gender.addItems(["ذكر", "أنثى"])
        if self.customer.get("gender") in ("ذكر", "أنثى"):
            self.gender.setCurrentText(self.customer["gender"])
        self.address = QLineEdit(str(self.customer.get("address", "")))
        self.notes = QTextEdit(str(self.customer.get("notes", ""))); self.notes.setFixedHeight(65)
        self.alert = QLineEdit(str(self.customer.get("important_alert", "")))
        tags = self.customer.get("tags", [])
        self.tags = QLineEdit(", ".join(tags if isinstance(tags, list) else []))
        self.discount = QDoubleSpinBox(); self.discount.setRange(0, 100); self.discount.setSuffix(" %"); self.discount.setValue(float(self.customer.get("default_discount_percent", 0) or 0))
        form.addRow("الاسم *", self.name)
        form.addRow("الموبايل *", self.phone)
        form.addRow("موبايل بديل", self.alt)
        form.addRow("السن", self.age)
        form.addRow("تاريخ الميلاد", self.birth)
        form.addRow("النوع", self.gender)
        form.addRow("العنوان", self.address)
        form.addRow("ملاحظات", self.notes)
        form.addRow("تنبيه مهم", self.alert)
        form.addRow("Tags (بفاصلة)", self.tags)
        form.addRow("خصم افتراضي", self.discount)
        buttons = QHBoxLayout()
        save = QPushButton("حفظ"); save.setObjectName("primaryButton"); save.clicked.connect(self.accept_checked)
        cancel = QPushButton("إلغاء"); cancel.clicked.connect(self.reject)
        buttons.addWidget(save); buttons.addWidget(cancel)
        form.addRow(buttons)

    def accept_checked(self):
        if not self.name.text().strip():
            QMessageBox.warning(self, "بيانات العميل", "اكتب اسم العميل")
            return
        if self.age.text().strip():
            try:
                age = int(self.age.text())
                if not 0 <= age <= 120:
                    raise ValueError
            except Exception:
                QMessageBox.warning(self, "بيانات العميل", "اكتب سن صحيح")
                return
        self.accept()

    def data(self):
        return {
            "name": self.name.text(), "phone": self.phone.text(), "alternate_phone": self.alt.text(),
            "age": self.age.text().strip(), "birth_date": self.birth.text().strip(), "gender": self.gender.currentText(),
            "address": self.address.text(), "notes": self.notes.toPlainText(), "important_alert": self.alert.text(),
            "tags": [x.strip() for x in self.tags.text().split(",") if x.strip()],
            "default_discount_percent": self.discount.value(),
        }


class CustomerDetailDialog(QDialog):
    def __init__(self, main: MainWindow, customer: Dict[str, Any]):
        super().__init__(main)
        self.main = main
        self.customer = customer
        self.orders: List[Dict[str, Any]] = []
        self.setWindowTitle(f"ملف العميل - {customer.get('name')}")
        self.resize(980, 650)
        l = QVBoxLayout(self)
        head = QHBoxLayout()
        title = QLabel(customer.get("name", "")); title.setObjectName("pageTitle")
        info = QLabel(f"ملف: {customer.get('file_number','—')}   |   موبايل: {customer.get('phone','—')}")
        info.setObjectName("muted")
        head.addWidget(title); head.addStretch(); head.addWidget(info)
        l.addLayout(head)
        if customer.get("important_alert"):
            alert = QLabel("⚠ " + str(customer.get("important_alert")))
            alert.setObjectName("alertBox"); alert.setWordWrap(True); l.addWidget(alert)

        actions = QHBoxLayout()
        edit = QPushButton("تعديل البيانات"); edit.clicked.connect(self.edit_customer)
        new = QPushButton("طلب جديد"); new.setObjectName("primaryButton"); new.clicked.connect(self.new_order)
        refresh = QPushButton("تحديث الطلبات"); refresh.clicked.connect(self.load_orders)
        actions.addWidget(edit); actions.addWidget(new); actions.addWidget(refresh)
        if main.client.is_manager:
            black = QPushButton("فك البلاك ليست" if customer.get("is_blacklisted") else "إضافة للبلاك ليست")
            black.setObjectName("dangerButton" if not customer.get("is_blacklisted") else "")
            black.clicked.connect(self.toggle_blacklist)
            archive = QPushButton("استرجاع" if customer.get("is_archived") else "حذف آمن")
            archive.clicked.connect(self.toggle_archive)
            actions.addWidget(black); actions.addWidget(archive)
        actions.addStretch()
        l.addLayout(actions)

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["رقم الطلب", "التاريخ", "التحاليل", "الإجمالي", "المدفوع", "المتبقي", "الحالة"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        l.addWidget(self.table, 1)
        self.summary = QLabel(""); self.summary.setObjectName("summaryBar"); l.addWidget(self.summary)
        self.load_orders()

    def load_orders(self):
        def task():
            docs = self.main.client.list_collection(f"customers/{self.customer['_id']}/orders")
            docs.sort(key=lambda d: int(d.get("created_at_ms", 0) or 0), reverse=True)
            return docs
        def ok(docs):
            self.orders = docs
            self.table.setRowCount(len(docs))
            for r, o in enumerate(docs):
                status = {"paid":"مدفوع", "partial":"جزئي", "unpaid":"غير مدفوع"}.get(str(o.get("payment_status")), str(o.get("payment_status", "")))
                if o.get("is_voided"):
                    status = "ملغي"
                vals = [o.get("order_number", ""), friendly_time(int(o.get("created_at_ms", 0) or 0)), o.get("tests_count", len(o.get("items", []))), money(float(o.get("total_customer_price",0) or 0)), money(float(o.get("paid_amount",0) or 0)), money(float(o.get("remaining_amount",0) or 0)), status]
                for col, val in enumerate(vals):
                    self.table.setItem(r, col, QTableWidgetItem(str(val)))
            total = sum(float(o.get("total_customer_price", 0) or 0) for o in docs if not o.get("is_voided"))
            debt = sum(float(o.get("remaining_amount", 0) or 0) for o in docs if not o.get("is_voided"))
            self.summary.setText(f"عدد الطلبات: {len(docs)}     إجمالي التعاملات: {money(total)} ج     المديونية: {money(debt)} ج")
        self.main.run_async(task, ok=ok)

    def edit_customer(self):
        dlg = CustomerEditDialog(self.main, self.customer)
        if dlg.exec() == QDialog.Accepted:
            page = self.main.customers_page
            page.save_customer(dlg.data(), self.customer)
            self.accept()

    def new_order(self):
        if self.customer.get("is_blacklisted"):
            QMessageBox.warning(self, "بلاك ليست", "لا يمكن إنشاء طلب جديد قبل فك الحظر")
            return
        if self.customer.get("is_archived"):
            QMessageBox.warning(self, "عميل مؤرشف", "لا يمكن إنشاء طلب جديد")
            return
        dlg = NewOrderDialog(self.main, self.customer)
        if dlg.exec() == QDialog.Accepted:
            self.load_orders()

    def toggle_blacklist(self):
        if not self.main.client.is_manager:
            return
        target = not bool(self.customer.get("is_blacklisted"))
        reason = ""
        if target:
            reason, ok = QInputDialog.getText(self, "سبب البلاك ليست", "اكتب السبب:")
            if not ok or len(reason.strip()) < 3:
                return
        def task():
            ts = now_ms()
            data = {"is_blacklisted": target, "blacklist_reason": reason.strip() if target else "", "blacklisted_at_ms": ts if target else 0, "updated_at_ms": ts, "updated_by_uid": self.main.client.uid, "updated_by_email": self.main.client.email}
            self.main.client.set_document(f"customers/{self.customer['_id']}", data, merge=True)
            self.main.log_audit("customer_blacklist" if target else "customer_unblacklist", "customer", self.customer["_id"], "بلاك ليست" if target else "فك البلاك ليست", reason or self.customer.get("name", ""), customer_id=self.customer["_id"])
            return True
        def ok(_):
            QMessageBox.information(self, "تم", "تم تحديث حالة العميل")
            self.accept(); self.main.customers_page.refresh()
        self.main.run_async(task, ok=ok)

    def toggle_archive(self):
        if not self.main.client.is_manager:
            return
        target = not bool(self.customer.get("is_archived"))
        if target and QMessageBox.question(self, "حذف آمن", "سيتم إخفاء العميل مع الاحتفاظ بكل طلباته. متابعة؟") != QMessageBox.Yes:
            return
        def task():
            ts = now_ms()
            self.main.client.set_document(f"customers/{self.customer['_id']}", {"is_archived": target, "archived_at_ms": ts if target else 0, "updated_at_ms": ts, "updated_by_uid": self.main.client.uid, "updated_by_email": self.main.client.email}, merge=True)
            self.main.log_audit("customer_archive" if target else "customer_restore", "customer", self.customer["_id"], "حذف آمن" if target else "استرجاع العميل", self.customer.get("name", ""), customer_id=self.customer["_id"])
            return True
        self.main.run_async(task, ok=lambda _: (QMessageBox.information(self, "تم", "تم تحديث حالة العميل"), self.accept(), self.main.customers_page.refresh()))


class NewOrderDialog(QDialog):
    def __init__(self, main: MainWindow, customer: Dict[str, Any]):
        super().__init__(main)
        self.main = main
        self.customer = customer
        self.selected: Dict[int, Dict[str, Any]] = {}
        self.setWindowTitle(f"طلب جديد - {customer.get('name')}")
        self.resize(1050, 720)
        root = QVBoxLayout(self)
        title = QLabel(f"طلب جديد • {customer.get('name')} • {customer.get('file_number','')}")
        title.setObjectName("pageTitle")
        root.addWidget(title)

        split = QSplitter()
        left = QWidget(); ll = QVBoxLayout(left)
        self.search = QLineEdit(); self.search.setPlaceholderText("ابحث عن تحليل بالعربي أو الإنجليزي أو الاسم الدارج..."); self.search.textChanged.connect(self.fill_tests)
        self.tests_table = QTableWidget(0, 4); self.tests_table.setHorizontalHeaderLabels(["التحليل", "الاسم العربي", "الاسم الدارج", "السعر"]); self.tests_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.tests_table.setSelectionBehavior(QAbstractItemView.SelectRows); self.tests_table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.tests_table.doubleClicked.connect(self.add_test)
        add = QPushButton("إضافة التحليل المحدد"); add.clicked.connect(self.add_test)
        ll.addWidget(self.search); ll.addWidget(self.tests_table); ll.addWidget(add)

        right = QWidget(); rl = QVBoxLayout(right)
        lab = QLabel("التحاليل المختارة"); lab.setObjectName("sectionTitle")
        self.sel_table = QTableWidget(0, 3); self.sel_table.setHorizontalHeaderLabels(["التحليل", "السعر", "حذف"]); self.sel_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.sel_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        rl.addWidget(lab); rl.addWidget(self.sel_table)
        split.addWidget(left); split.addWidget(right); split.setSizes([600, 450])
        root.addWidget(split, 1)

        finance = QGroupBox("الحساب والدفع")
        fg = QGridLayout(finance)
        self.before = QLabel("0 ج"); self.before.setObjectName("moneyBig")
        self.discount_mode = QComboBox(); self.discount_mode.addItems(["نسبة %", "مبلغ"]); self.discount_mode.currentIndexChanged.connect(self.recalc)
        self.discount = QDoubleSpinBox(); self.discount.setRange(0, 1000000); self.discount.valueChanged.connect(self.recalc)
        default_pct = float(customer.get("default_discount_percent", 0) or 0); self.discount.setValue(default_pct)
        self.after = QLabel("0 ج"); self.after.setObjectName("moneyBig")
        self.payment = QComboBox(); self.payment.addItems(["غير مدفوع", "مدفوع جزئي", "مدفوع بالكامل"]); self.payment.currentIndexChanged.connect(self.recalc)
        self.paid = QDoubleSpinBox(); self.paid.setRange(0, 10000000); self.paid.valueChanged.connect(self.recalc)
        self.remaining = QLabel("0 ج")
        self.notes = QLineEdit(); self.notes.setPlaceholderText("ملاحظات على الطلب")
        fg.addWidget(QLabel("قبل الخصم"),0,0); fg.addWidget(self.before,1,0)
        fg.addWidget(self.discount_mode,0,1); fg.addWidget(self.discount,1,1)
        fg.addWidget(QLabel("بعد الخصم"),0,2); fg.addWidget(self.after,1,2)
        fg.addWidget(QLabel("حالة الدفع"),2,0); fg.addWidget(self.payment,3,0)
        fg.addWidget(QLabel("المدفوع"),2,1); fg.addWidget(self.paid,3,1)
        fg.addWidget(QLabel("المتبقي"),2,2); fg.addWidget(self.remaining,3,2)
        fg.addWidget(self.notes,4,0,1,3)
        root.addWidget(finance)
        save = QPushButton("حفظ الطلب"); save.setObjectName("primaryButton"); save.clicked.connect(self.save_order); root.addWidget(save)
        self.fill_tests(); self.refresh_selected(); self.recalc()

    def fill_tests(self):
        q = normalize_text(self.search.text())
        rows = []
        for t in self.main.tests:
            blob = normalize_text(" ".join([str(t.get("english_name","")), str(t.get("arabic_name","")), str(t.get("market_name","")), str(t.get("search_text",""))]))
            if (not q or q in blob) and int(t["id"]) not in self.selected:
                rows.append(t)
            if len(rows) >= 120:
                break
        self.tests_table.setRowCount(len(rows))
        for r,t in enumerate(rows):
            vals = [t.get("english_name",""), t.get("arabic_name",""), t.get("market_name",""), money(self.main.effective_price(t))]
            for c,val in enumerate(vals):
                item = QTableWidgetItem(str(val)); item.setData(Qt.UserRole, t); self.tests_table.setItem(r,c,item)

    def add_test(self):
        r = self.tests_table.currentRow()
        if r < 0: return
        t = self.tests_table.item(r,0).data(Qt.UserRole)
        self.selected[int(t["id"])] = t
        self.fill_tests(); self.refresh_selected(); self.recalc()

    def remove_test(self, tid: int):
        self.selected.pop(tid, None); self.fill_tests(); self.refresh_selected(); self.recalc()

    def refresh_selected(self):
        vals = list(self.selected.values())
        self.sel_table.setRowCount(len(vals))
        for r,t in enumerate(vals):
            self.sel_table.setItem(r,0,QTableWidgetItem(str(t.get("market_name") or t.get("english_name"))))
            self.sel_table.setItem(r,1,QTableWidgetItem(money(self.main.effective_price(t))))
            b = QPushButton("✕"); b.clicked.connect(lambda _=False, tid=int(t["id"]): self.remove_test(tid)); self.sel_table.setCellWidget(r,2,b)

    def totals(self):
        subtotal = sum(self.main.effective_price(t) for t in self.selected.values())
        if self.discount_mode.currentIndex() == 0:
            pct = min(self.discount.value(), 100.0)
            disc = subtotal * pct / 100.0
        else:
            disc = min(self.discount.value(), subtotal)
            pct = (disc / subtotal * 100.0) if subtotal else 0.0
        final = max(0.0, subtotal - disc)
        status_idx = self.payment.currentIndex()
        if status_idx == 0:
            paid = 0.0
        elif status_idx == 2:
            paid = final
        else:
            paid = min(self.paid.value(), final)
        remaining = max(0.0, final - paid)
        return subtotal, disc, pct, final, paid, remaining

    def recalc(self):
        subtotal, disc, pct, final, paid, remaining = self.totals()
        self.before.setText(f"{money(subtotal)} ج")
        self.after.setText(f"{money(final)} ج")
        self.remaining.setText(f"{money(remaining)} ج")
        self.paid.setEnabled(self.payment.currentIndex() == 1)
        if self.payment.currentIndex() == 2 and abs(self.paid.value()-final) > .01:
            self.paid.blockSignals(True); self.paid.setValue(final); self.paid.blockSignals(False)
        elif self.payment.currentIndex() == 0 and self.paid.value() != 0:
            self.paid.blockSignals(True); self.paid.setValue(0); self.paid.blockSignals(False)

    def save_order(self):
        if not self.selected:
            QMessageBox.warning(self, "الطلب", "اختر تحليل واحد على الأقل")
            return
        subtotal, disc, pct, final, paid, remaining = self.totals()
        status = "paid" if remaining <= .001 else ("partial" if paid > 0 else "unpaid")
        tests = list(self.selected.values())
        def task():
            ts = now_ms(); oid = self.main.client.new_id(); order_no = generate_order_number(ts, oid)
            items = [{"test_id": int(t["id"]), "english_name": t.get("english_name",""), "arabic_name": t.get("arabic_name",""), "market_name": t.get("market_name",""), "customer_price": self.main.effective_price(t)} for t in tests]
            payload = {
                "order_number": order_no, "customer_id": self.customer["_id"], "customer_file_number": self.customer.get("file_number",""), "customer_name": self.customer.get("name",""), "customer_phone": self.customer.get("phone",""),
                "items": items, "tests_count": len(items), "subtotal_customer_price": subtotal, "discount_amount": disc, "discount_percent": pct, "total_customer_price": final,
                "payment_status": status, "paid_amount": paid, "remaining_amount": remaining, "notes": self.notes.text().strip(),
                "created_at_ms": ts, "created_by_uid": self.main.client.uid, "created_by_email": self.main.client.email,
                "updated_at_ms": ts, "updated_by_uid": self.main.client.uid, "edit_count": 0, "is_voided": False, "void_reason": ""
            }
            self.main.client.set_document(f"customers/{self.customer['_id']}/orders/{oid}", payload, merge=False)
            if paid > 0:
                pid = self.main.client.new_id()
                self.main.client.set_document(f"customers/{self.customer['_id']}/orders/{oid}/payments/{pid}", {"customer_id": self.customer["_id"], "order_id": oid, "amount": paid, "note": "دفعة عند إنشاء الطلب", "created_at_ms": ts, "created_by_uid": self.main.client.uid, "created_by_email": self.main.client.email}, merge=False)
            detail = f"{order_no} • {len(items)} تحليل • إجمالي {money(final)} • خصم {money(disc)}"
            self.main.log_audit("order_create", "order", oid, "إنشاء طلب", detail, customer_id=self.customer["_id"], order_id=oid)
            self.main.add_activity(self.customer["_id"], "order", f"طلب جديد {order_no}", detail)
            return order_no
        def ok(order_no):
            QMessageBox.information(self, "تم", f"تم حفظ الطلب {order_no}")
            self.accept()
        self.main.run_async(task, ok=ok)


class OrdersLookupPage(QWidget):
    def __init__(self, main: MainWindow):
        super().__init__()
        self.main = main
        l = QVBoxLayout(self); l.setContentsMargins(30,24,30,24)
        title = QLabel("طلبات العملاء"); title.setObjectName("pageTitle")
        note = QLabel("ابحث عن العميل أولًا ثم افتح ملفه لمراجعة الطلبات أو إنشاء طلب جديد."); note.setObjectName("muted")
        go = QPushButton("فتح العملاء"); go.setObjectName("primaryButton"); go.clicked.connect(lambda: main.go("customers"))
        l.addWidget(title); l.addWidget(note); l.addWidget(go); l.addStretch()


class ReportsPage(QWidget):
    def __init__(self, main: MainWindow):
        super().__init__(); self.main=main; self.orders=[]
        l=QVBoxLayout(self); l.setContentsMargins(30,24,30,24)
        head=QHBoxLayout(); title=QLabel("التقارير والحسابات"); title.setObjectName("pageTitle")
        self.range=QComboBox(); self.range.addItems(["اليوم","آخر 7 أيام","آخر 30 يوم","هذا الشهر"]); self.range.currentIndexChanged.connect(self.refresh)
        ref=QPushButton("تحديث"); ref.clicked.connect(self.refresh)
        head.addWidget(title); head.addStretch(); head.addWidget(self.range); head.addWidget(ref); l.addLayout(head)
        cards=QGridLayout(); self.orders_card=Card("الطلبات","—"); self.sales=Card("المبيعات","—"); self.paid=Card("التحصيل","—"); self.debt=Card("المتبقي","—"); self.disc=Card("الخصومات","—")
        for i,c in enumerate([self.orders_card,self.sales,self.paid,self.debt,self.disc]): cards.addWidget(c,i//3,i%3)
        l.addLayout(cards)
        self.table=QTableWidget(0,7); self.table.setHorizontalHeaderLabels(["رقم الطلب","العميل","التاريخ","الإجمالي","الخصم","المدفوع","المتبقي"]); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.table.setEditTriggers(QAbstractItemView.NoEditTriggers); l.addWidget(self.table,1)

    def on_show(self):
        if self.main.client.is_manager: self.refresh()

    def _range_ms(self):
        now=datetime.now(); idx=self.range.currentIndex()
        if idx==0: start=now.replace(hour=0,minute=0,second=0,microsecond=0)
        elif idx==1: start=now-timedelta(days=7)
        elif idx==2: start=now-timedelta(days=30)
        else: start=now.replace(day=1,hour=0,minute=0,second=0,microsecond=0)
        return int(start.timestamp()*1000), int(now.timestamp()*1000)

    def refresh(self):
        if not self.main.client.is_manager: return
        frm,to=self._range_ms()
        def task():
            docs=self.main.client.run_collection_group("orders")
            return [o for o in docs if frm <= int(o.get("created_at_ms",0) or 0) <= to and not o.get("is_voided",False)]
        def ok(docs):
            docs.sort(key=lambda o:int(o.get("created_at_ms",0) or 0),reverse=True); self.orders=docs
            sales=sum(float(o.get("total_customer_price",0) or 0) for o in docs); paid=sum(float(o.get("paid_amount",0) or 0) for o in docs); debt=sum(float(o.get("remaining_amount",0) or 0) for o in docs); disc=sum(float(o.get("discount_amount",0) or 0) for o in docs)
            self.orders_card.set_value(str(len(docs))); self.sales.set_value(f"{money(sales)} ج"); self.paid.set_value(f"{money(paid)} ج"); self.debt.set_value(f"{money(debt)} ج"); self.disc.set_value(f"{money(disc)} ج")
            self.table.setRowCount(len(docs))
            for r,o in enumerate(docs):
                vals=[o.get("order_number",""),o.get("customer_name",""),friendly_time(int(o.get("created_at_ms",0) or 0)),money(float(o.get("total_customer_price",0) or 0)),money(float(o.get("discount_amount",0) or 0)),money(float(o.get("paid_amount",0) or 0)),money(float(o.get("remaining_amount",0) or 0))]
                for c,v in enumerate(vals): self.table.setItem(r,c,QTableWidgetItem(str(v)))
        self.main.run_async(task,ok=ok)


class AdminPage(QWidget):
    def __init__(self, main: MainWindow):
        super().__init__(); self.main=main; self.users=[]
        l=QVBoxLayout(self); l.setContentsMargins(30,24,30,24)
        title=QLabel("الإدارة"); title.setObjectName("pageTitle"); l.addWidget(title)
        buttons=QHBoxLayout(); add=QPushButton("+ مستخدم جديد"); add.setObjectName("primaryButton"); add.clicked.connect(self.add_user); ref=QPushButton("تحديث المستخدمين"); ref.clicked.connect(self.refresh_users); toggle=QPushButton("تفعيل / إيقاف المحدد"); toggle.clicked.connect(self.toggle_user); reset=QPushButton("Reset PIN"); reset.clicked.connect(self.reset_pin)
        buttons.addWidget(add); buttons.addWidget(ref); buttons.addWidget(toggle); buttons.addWidget(reset); buttons.addStretch(); l.addLayout(buttons)
        self.table=QTableWidget(0,5); self.table.setHorizontalHeaderLabels(["الاسم","البريد","الدور","الحالة","UID"]); self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); self.table.setSelectionBehavior(QAbstractItemView.SelectRows); self.table.setEditTriggers(QAbstractItemView.NoEditTriggers); l.addWidget(self.table,1)
        note=QLabel("Lab2Lab والتقارير العامة لا تظهر إلا لحساب عبدالرحمن. نفس Firestore Rules الخاصة بتطبيق الموبايل هي التي تحمي البيانات."); note.setObjectName("muted"); note.setWordWrap(True); l.addWidget(note)

    def on_show(self): self.refresh_users()
    def refresh_users(self):
        if not self.main.client.is_manager:return
        self.main.run_async(lambda:self.main.client.list_collection("users"),ok=self._show_users)
    def _show_users(self,docs):
        self.users=docs; self.table.setRowCount(len(docs))
        for r,u in enumerate(docs):
            vals=[u.get("display_name",""),u.get("email",""),u.get("role","staff"),"نشط" if u.get("enabled",True) else "موقوف",u.get("_id","")]
            for c,v in enumerate(vals):
                it=QTableWidgetItem(str(v)); it.setData(Qt.UserRole,u); self.table.setItem(r,c,it)
    def selected(self):
        r=self.table.currentRow()
        if r<0: QMessageBox.information(self,"الإدارة","اختر مستخدم أولًا"); return None
        return self.table.item(r,0).data(Qt.UserRole)
    def add_user(self):
        dlg=QDialog(self); dlg.setWindowTitle("مستخدم جديد"); f=QFormLayout(dlg); name=QLineEdit(); email=QLineEdit(); password=QLineEdit(); password.setEchoMode(QLineEdit.Password); role=QComboBox(); role.addItems(["staff","reception","cashier","supervisor","manager"]); b=QPushButton("إنشاء"); b.setObjectName("primaryButton"); b.clicked.connect(dlg.accept); f.addRow("الاسم",name); f.addRow("البريد",email); f.addRow("كلمة المرور",password); f.addRow("الدور",role); f.addRow(b)
        if dlg.exec()!=QDialog.Accepted:return
        if len(password.text())<6 or "@" not in email.text(): QMessageBox.warning(self,"مستخدم جديد","تأكد من البريد وكلمة مرور 6 حروف على الأقل"); return
        def task():
            new=self.main.client.create_auth_user(email.text().strip(),password.text())
            uid=new["localId"]; ts=now_ms(); data={"email":email.text().strip().lower(),"display_name":name.text().strip() or email.text().split('@')[0],"role":role.currentText(),"enabled":True,"can_edit_customers":True,"can_discount":True,"can_collect_payments":True,"can_view_sales_reports":False,"created_at_ms":ts,"updated_at_ms":ts}
            self.main.client.set_document(f"users/{uid}",data,merge=False); self.main.log_audit("user_create","user",uid,"إنشاء مستخدم",data["display_name"]); return True
        self.main.run_async(task,ok=lambda _: (QMessageBox.information(self,"تم","تم إنشاء المستخدم"),self.refresh_users()))
    def toggle_user(self):
        u=self.selected();
        if not u:return
        if u.get("_id")==MANAGER_UID: QMessageBox.warning(self,"الإدارة","لا يمكن إيقاف حساب عبدالرحمن"); return
        enabled=not bool(u.get("enabled",True))
        def task(): self.main.client.set_document(f"users/{u['_id']}",{"enabled":enabled,"updated_at_ms":now_ms()},merge=True); self.main.log_audit("user_enable" if enabled else "user_disable","user",u["_id"],"تفعيل مستخدم" if enabled else "إيقاف مستخدم",u.get("display_name","")); return True
        self.main.run_async(task,ok=lambda _: self.refresh_users())
    def reset_pin(self):
        u=self.selected();
        if not u:return
        def task(): self.main.client.set_document(f"users/{u['_id']}",{"pin_reset_requested_at_ms":now_ms(),"updated_at_ms":now_ms()},merge=True); self.main.log_audit("pin_reset","user",u["_id"],"طلب Reset PIN",u.get("display_name","")); return True
        self.main.run_async(task,ok=lambda _: QMessageBox.information(self,"تم","هيتم إلغاء PIN عند فتح تطبيق الموبايل على جهاز المستخدم"))


def apply_style(app: QApplication):
    app.setLayoutDirection(Qt.RightToLeft)
    app.setFont(QFont("Segoe UI", 10))
    app.setStyleSheet(r'''
        QWidget { background: #f6f8fb; color: #172033; font-size: 14px; }
        QMainWindow, QDialog { background: #f6f8fb; }
        QLineEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit {
            background: white; border: 1px solid #d8dee9; border-radius: 9px; padding: 9px; min-height: 22px;
        }
        QPushButton { background: white; border: 1px solid #d8dee9; border-radius: 9px; padding: 9px 14px; }
        QPushButton:hover { background: #eef3fb; }
        QPushButton#primaryButton { background: #1769e0; color: white; border: none; font-weight: 700; }
        QPushButton#dangerButton { background: #fff1f1; color: #b42318; border: 1px solid #fecaca; }
        QFrame#sidebar { background: #111827; color: white; }
        QFrame#sidebar QLabel { background: transparent; color: white; }
        QLabel#brand { font-size: 25px; font-weight: 800; color: white; }
        QLabel#sidebarUser { color: #cbd5e1; line-height: 1.4; }
        QPushButton#navButton { background: transparent; color: #e5e7eb; border: none; text-align: right; padding: 11px; font-weight: 600; }
        QPushButton#navButton:hover { background: #1f2937; }
        QLabel#pageTitle, QLabel#loginTitle { font-size: 28px; font-weight: 800; color: #111827; }
        QLabel#sectionTitle { font-size: 18px; font-weight: 700; }
        QLabel#muted { color: #667085; }
        QLabel#error { color: #b42318; }
        QFrame#card { background: white; border: 1px solid #e5e7eb; border-radius: 14px; padding: 10px; }
        QLabel#cardTitle { color: #667085; font-weight: 700; }
        QLabel#cardValue { color: #111827; font-size: 25px; font-weight: 800; }
        QPushButton#actionTile { background: white; border: 1px solid #e3e8ef; border-radius: 16px; font-size: 18px; font-weight: 800; }
        QPushButton#actionTile:hover { background: #edf5ff; border-color: #aacbfa; }
        QLabel#alertBox { background: #fff7ed; color: #9a3412; border: 1px solid #fed7aa; border-radius: 10px; padding: 11px; font-weight: 700; }
        QLabel#summaryBar { background: white; border: 1px solid #e5e7eb; border-radius: 10px; padding: 11px; font-weight: 700; }
        QLabel#moneyBig { font-size: 21px; font-weight: 800; color: #1769e0; }
        QTableWidget { background: white; alternate-background-color: #f8fafc; border: 1px solid #e5e7eb; border-radius: 10px; gridline-color: #edf0f4; }
        QHeaderView::section { background: #eef2f7; padding: 9px; border: none; font-weight: 700; }
        QGroupBox { background: white; border: 1px solid #e5e7eb; border-radius: 12px; margin-top: 12px; padding: 12px; font-weight: 700; }
        QGroupBox::title { subcontrol-origin: margin; right: 12px; padding: 0 6px; }
    ''')


def main():
    app = QApplication(sys.argv)
    apply_style(app)
    w = LoginWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
