from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests


class FirebaseError(RuntimeError):
    pass


def _encode_value(value: Any) -> Dict[str, Any]:
    if value is None:
        return {"nullValue": None}
    if isinstance(value, bool):
        return {"booleanValue": value}
    if isinstance(value, int) and not isinstance(value, bool):
        return {"integerValue": str(value)}
    if isinstance(value, float):
        return {"doubleValue": value}
    if isinstance(value, str):
        return {"stringValue": value}
    if isinstance(value, list):
        return {"arrayValue": {"values": [_encode_value(v) for v in value]}}
    if isinstance(value, dict):
        return {"mapValue": {"fields": {str(k): _encode_value(v) for k, v in value.items()}}}
    return {"stringValue": str(value)}


def _decode_value(value: Dict[str, Any]) -> Any:
    if not value:
        return None
    if "nullValue" in value:
        return None
    if "stringValue" in value:
        return value["stringValue"]
    if "integerValue" in value:
        try:
            return int(value["integerValue"])
        except Exception:
            return 0
    if "doubleValue" in value:
        return float(value["doubleValue"])
    if "booleanValue" in value:
        return bool(value["booleanValue"])
    if "timestampValue" in value:
        return value["timestampValue"]
    if "arrayValue" in value:
        return [_decode_value(v) for v in value.get("arrayValue", {}).get("values", [])]
    if "mapValue" in value:
        fields = value.get("mapValue", {}).get("fields", {})
        return {k: _decode_value(v) for k, v in fields.items()}
    return None


def _encode_fields(data: Dict[str, Any]) -> Dict[str, Any]:
    return {k: _encode_value(v) for k, v in data.items()}


def _decode_document(doc: Dict[str, Any]) -> Dict[str, Any]:
    fields = {k: _decode_value(v) for k, v in doc.get("fields", {}).items()}
    name = doc.get("name", "")
    fields["_id"] = name.rsplit("/", 1)[-1] if name else ""
    fields["_name"] = name
    fields["_createTime"] = doc.get("createTime", "")
    fields["_updateTime"] = doc.get("updateTime", "")
    return fields


class FirebaseClient:
    def __init__(self, config_path: str | Path):
        cfg = json.loads(Path(config_path).read_text(encoding="utf-8"))
        self.api_key = cfg["firebase_api_key"]
        self.project_id = cfg["firebase_project_id"]
        self.manager_uid = cfg["manager_uid"]
        self.id_token = ""
        self.refresh_token = ""
        self.uid = ""
        self.email = ""
        self.expiry = 0.0
        self.session = requests.Session()
        self.base = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents"

    @property
    def is_manager(self) -> bool:
        return bool(self.uid and self.uid == self.manager_uid)

    def sign_in(self, email: str, password: str) -> Dict[str, Any]:
        url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={self.api_key}"
        r = self.session.post(url, json={"email": email, "password": password, "returnSecureToken": True}, timeout=20)
        if r.status_code >= 400:
            msg = r.json().get("error", {}).get("message", "LOGIN_FAILED")
            raise FirebaseError(self._friendly_auth_error(msg))
        data = r.json()
        self.id_token = data["idToken"]
        self.refresh_token = data["refreshToken"]
        self.uid = data["localId"]
        self.email = data.get("email", email)
        self.expiry = time.time() + int(data.get("expiresIn", "3600")) - 60
        return data

    def _friendly_auth_error(self, code: str) -> str:
        mapping = {
            "INVALID_LOGIN_CREDENTIALS": "البريد الإلكتروني أو كلمة المرور غير صحيحة",
            "EMAIL_NOT_FOUND": "الحساب غير موجود",
            "INVALID_PASSWORD": "كلمة المرور غير صحيحة",
            "USER_DISABLED": "هذا الحساب موقوف",
            "TOO_MANY_ATTEMPTS_TRY_LATER": "محاولات كثيرة. حاول بعد قليل",
        }
        return mapping.get(code, f"تعذر تسجيل الدخول: {code}")

    def refresh(self) -> None:
        if not self.refresh_token:
            raise FirebaseError("انتهت جلسة تسجيل الدخول")
        url = f"https://securetoken.googleapis.com/v1/token?key={self.api_key}"
        r = self.session.post(url, data={"grant_type": "refresh_token", "refresh_token": self.refresh_token}, timeout=20)
        if r.status_code >= 400:
            raise FirebaseError("انتهت الجلسة. سجل الدخول مرة أخرى")
        data = r.json()
        self.id_token = data["id_token"]
        self.refresh_token = data["refresh_token"]
        self.uid = data["user_id"]
        self.expiry = time.time() + int(data.get("expires_in", "3600")) - 60

    def _headers(self) -> Dict[str, str]:
        if time.time() >= self.expiry:
            self.refresh()
        return {"Authorization": f"Bearer {self.id_token}", "Content-Type": "application/json"}

    def _request(self, method: str, url: str, **kwargs) -> requests.Response:
        kwargs.setdefault("timeout", 25)
        kwargs["headers"] = {**self._headers(), **kwargs.pop("headers", {})}
        r = self.session.request(method, url, **kwargs)
        if r.status_code == 401 and self.refresh_token:
            self.refresh()
            kwargs["headers"] = self._headers()
            r = self.session.request(method, url, **kwargs)
        if r.status_code >= 400:
            try:
                detail = r.json().get("error", {}).get("message", r.text)
            except Exception:
                detail = r.text
            raise FirebaseError(detail or f"Firebase HTTP {r.status_code}")
        return r

    def get_document(self, path: str) -> Optional[Dict[str, Any]]:
        r = self._request("GET", f"{self.base}/{path}")
        return _decode_document(r.json())

    def get_document_optional(self, path: str) -> Optional[Dict[str, Any]]:
        try:
            return self.get_document(path)
        except FirebaseError as exc:
            if "NOT_FOUND" in str(exc) or "404" in str(exc):
                return None
            raise

    def list_collection(self, path: str, page_size: int = 1000) -> List[Dict[str, Any]]:
        docs: List[Dict[str, Any]] = []
        token = ""
        while True:
            params: Dict[str, Any] = {"pageSize": min(page_size, 1000)}
            if token:
                params["pageToken"] = token
            r = self._request("GET", f"{self.base}/{path}", params=params)
            data = r.json()
            docs.extend(_decode_document(d) for d in data.get("documents", []))
            token = data.get("nextPageToken", "")
            if not token:
                break
        return docs

    def set_document(self, path: str, data: Dict[str, Any], merge: bool = True) -> Dict[str, Any]:
        params = []
        if merge:
            params = [("updateMask.fieldPaths", k) for k in data.keys()]
        r = self._request("PATCH", f"{self.base}/{path}", params=params, json={"fields": _encode_fields(data)})
        return _decode_document(r.json())

    def delete_document(self, path: str) -> None:
        self._request("DELETE", f"{self.base}/{path}")

    def new_id(self) -> str:
        return uuid.uuid4().hex

    def run_collection_group(self, collection_id: str) -> List[Dict[str, Any]]:
        url = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents:runQuery"
        body = {"structuredQuery": {"from": [{"collectionId": collection_id, "allDescendants": True}]}}
        r = self._request("POST", url, json=body)
        out = []
        for row in r.json():
            if row.get("document"):
                out.append(_decode_document(row["document"]))
        return out

    def get_or_create_profile(self) -> Dict[str, Any]:
        path = f"users/{self.uid}"
        try:
            profile = self.get_document(path)
        except FirebaseError as exc:
            if "NOT_FOUND" not in str(exc):
                raise
            profile = None
        if profile:
            return profile
        now = int(time.time() * 1000)
        data = {
            "email": self.email.lower(),
            "display_name": self.email.split("@")[0] or "مستخدم",
            "role": "staff",
            "enabled": True,
            "can_edit_customers": True,
            "can_discount": True,
            "can_collect_payments": True,
            "can_view_sales_reports": False,
            "created_at_ms": now,
            "updated_at_ms": now,
        }
        return self.set_document(path, data, merge=False)

    def create_auth_user(self, email: str, password: str) -> Dict[str, Any]:
        if not self.is_manager:
            raise FirebaseError("الإجراء متاح لعبدالرحمن فقط")
        url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={self.api_key}"
        r = self.session.post(url, json={"email": email, "password": password, "returnSecureToken": True}, timeout=20)
        if r.status_code >= 400:
            msg = r.json().get("error", {}).get("message", r.text)
            raise FirebaseError(msg)
        return r.json()
